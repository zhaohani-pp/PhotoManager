package com.myname.gallery;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
