<template>
  <router-view />
</template>

<style>
body { margin: 0; font-family: 'Helvetica Neue', Helvetica, sans-serif; }
</style>